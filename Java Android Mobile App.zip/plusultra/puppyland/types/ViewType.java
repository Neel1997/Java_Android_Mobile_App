package com.plusultra.puppyland.types;

public enum ViewType {
    COLLECTION,
    MENU,
    LOADING,
    GAME,
    HIT,
    PARK
}
