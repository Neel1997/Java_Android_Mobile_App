package com.plusultra.puppyland.types;

public enum UserDataType {

    GROUND,
    RUNNER,
    HAZARD,
    TREAT,
    DOG

}