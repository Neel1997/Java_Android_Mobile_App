package com.plusultra.puppyland.box2d;

import com.plusultra.puppyland.types.UserDataType;

public class GroundUserData extends UserData {

    public GroundUserData() {
        super();
        userDataType = UserDataType.GROUND;
    }

}